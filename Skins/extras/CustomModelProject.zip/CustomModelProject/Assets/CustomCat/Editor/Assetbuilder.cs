using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public class Assetbuilder : MonoBehaviour
{
    //build assetbundles
    [MenuItem("Little Kitty Big City/Build Bundles")]
    static void BuildAllAssetBundles()
    {
        //  output path
        string assetBundleDirectory = "Assets/CustomCat/Bundles/";
        Directory.CreateDirectory(assetBundleDirectory);

        //  build
        BuildPipeline.BuildAssetBundles(assetBundleDirectory, BuildAssetBundleOptions.ChunkBasedCompression, BuildTarget.StandaloneWindows64);
        AssetDatabase.Refresh();

        //  console notification
        Debug.Log("<color=lime>Assets built! </color>Located under: 'CustomCat/Bundles/'");
    }
}
