using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor.AssetImporters;
using UnityEngine;

[ScriptedImporter(1, "kitty")]
public class KittyImporter : ScriptedImporter
{
    public override void OnImportAsset(AssetImportContext ctx)
    {
        TextAsset desc = new TextAsset("-   Custom Player Model   -\n\nDrag into 'Skins/models/' folder, rename to 'Current.kitty', then launch game with Big City Custom Kitty to load\n\nAsset Generated on: " + DateTime.Now);
        Texture2D icon = Resources.Load<Texture2D>("KittyIcon");

        ctx.AddObjectToAsset(ctx.assetPath, desc, icon);
    }
}
